//Crear, modificar, eliminar

package Principal;

import java.util.ArrayList;

public class ProcesoDatos {
    private ArrayList<Object> a = new ArrayList<Object>();
    
    //constructo vacio
    public ProcesoDatos(){
    }
    public ProcesoDatos(ArrayList<Object> a){
        this.a = a;
    }
    //crear un nuevo registro en un archivo plano
    public void crearRegistros(DatosPersonales p){
    this.a.add(p);
    }
    //modificarRegistro
    public void modificarRegistro (int i, DatosPersonales p){
    this.a.set(i, p);
    }
    //Eliminar Registros
    public void eliminarRegistros (int i){
        this.a.remove(i);
   
    }
    //Recorrido y obtener datos personales
    
    public DatosPersonales obtenerRegistro(int i){
    return (DatosPersonales)a.get(i);
    }
    //crear una clase que determine la cantidad de registro encontrados
    public int cantidadRegistros(){
        return this.a.size();    
    }
    //Crear un buscador
    public int buscarCodigo(int codigo){
        for(int i=0; i<cantidadRegistros();i++){
            if(codigo==obtenerRegistro(i).getCodigo())return i;
        }
        return -1;
    }
}
